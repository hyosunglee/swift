//
//  ContentView.swift
//  iobis WatchKit Extension
//
//  Created by vlmimac1 on 2022/04/13.
//

import SwiftUI



struct ContentView: View {
    
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Hello")
                    .navigationTitle("첫번째 페이지")
                
                NavigationLink(
                    destination: ShapeView(),
                    label: {
                        Text("Jabis")
                    })
            }
        }
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
