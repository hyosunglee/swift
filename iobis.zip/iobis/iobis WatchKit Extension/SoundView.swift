//
//  SoundView.swift
//  iobis WatchKit Extension
//
//  Created by vlmimac1 on 2022/04/13.
//
import WatchKit
import SwiftUI


struct SoundView: View {
    
    var body: some View {
        VStack{
            Text("음성분석을 시작합니다.")
            Button("자비스"){
            }
            
        }
        
    }
}

struct SoundView_Previews: PreviewProvider {
    static var previews: some View {
        SoundView()
    }
}
