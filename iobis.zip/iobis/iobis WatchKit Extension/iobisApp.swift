//
//  iobisApp.swift
//  iobis WatchKit Extension
//
//  Created by vlmimac1 on 2022/04/13.
//

import SwiftUI

@main
struct iobisApp: App {
    @SceneBuilder var body: some Scene {
        WindowGroup {
            NavigationView {
                ContentView()
            }
        }

        WKNotificationScene(controller: NotificationController.self, category: "myCategory")
    }
}
