//
//  ContentView.swift
//  iobis
//
//  Created by vlmimac1 on 2022/04/13.
//

import SwiftUI

struct ContentView: View {

    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
