//
//  Sound.swift
//  iobis
//
//  Created by vlmimac1 on 2022/04/13.
//

import UIKit
import WatchKit



class Sound: UIViewController{
    override func viewDidLoad() {
        super.viewDidLoad()
        let phrases = ["I'm in a meeting", "I'll call you later", "Call me later"]
        
        presentTextInputController(withSuggestions: phrases,
                                   allowedInputMode: .allowEmoji,
                    completion: { (result) -> Void in

            if let choice = result?[0] as? String {
                    print(choice)
            }
        })
        
    }
}
